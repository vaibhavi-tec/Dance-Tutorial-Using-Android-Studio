package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class bharathanatayam extends AppCompatActivity {
    Button begin5, inter5, adv5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bharathanatayam);
        begin5=(Button) findViewById(R.id.begin5);
        inter5=(Button) findViewById(R.id.inter5);
        adv5=(Button) findViewById(R.id.adv5);

        begin5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(bharathanatayam.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(bharathanatayam.this, bharbegin.class);
                startActivity(intent);
            }
        });

        inter5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(bharathanatayam.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(bharathanatayam.this, bharinter.class);
                startActivity(intent);
            }
        });

        adv5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(bharathanatayam.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(bharathanatayam.this, bharadv.class);
                startActivity(intent);
            }
        });
    }
}