package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class kathak extends AppCompatActivity {
    Button begin3, inter3, adv3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kathak);

        begin3=(Button) findViewById(R.id.begin3);
        inter3=(Button) findViewById(R.id.inter3);
        adv3=(Button) findViewById(R.id.adv3);

        begin3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(kathak.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(kathak.this, kathakbegin.class);
                startActivity(intent);
            }
        });

        inter3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(kathak.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(kathak.this, kathakinter.class);
                startActivity(intent);
            }
        });

        adv3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(kathak.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(kathak.this, kathakadv.class);
                startActivity(intent);
            }
        });
    }
}