package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class kpop extends AppCompatActivity {
    Button begin, inter, adv;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kpop);
        begin=(Button) findViewById(R.id.begin);
        inter=(Button) findViewById(R.id.inter);
        adv=(Button) findViewById(R.id.adv);

        begin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(kpop.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(kpop.this, kpopbegin.class);
                startActivity(intent);
            }
        });

        inter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(kpop.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(kpop.this, kpopinter.class);
                startActivity(intent);
            }
        });

        adv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(kpop.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(kpop.this, kpopadv.class);
                startActivity(intent);
            }
        });

    }

}