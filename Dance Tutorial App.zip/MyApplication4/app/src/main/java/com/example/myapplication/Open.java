package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Open extends AppCompatActivity  {
    private CardView D1, D2, D3, D4, D5, D6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open);

        D1 = (CardView) findViewById(R.id.d1);
        D2 = (CardView) findViewById(R.id.d2);
        D3 = (CardView) findViewById(R.id.d3);
        D4 = (CardView) findViewById(R.id.d4);
        D5 = (CardView) findViewById(R.id.d5);
        D6 = (CardView) findViewById(R.id.d6);

        D1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Open.this, "HAPPY LEARNING", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Open.this, hiphop.class);
                startActivity(intent);
            }
        });
        D2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Open.this, "HAPPY LEARNING", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Open.this, kpop.class);
                startActivity(intent);
            }
        });
        D3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Open.this, "HAPPY LEARNING", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Open.this, kathak.class);
                startActivity(intent);
            }
        });
        D4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Open.this, "HAPPY LEARNING", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Open.this, zumba.class);
                startActivity(intent);
            }
        });
        D5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Open.this, "HAPPY LEARNING", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Open.this, bharathanatayam.class);
                startActivity(intent);
            }
        });
        D6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Open.this, "HAPPY LEARNING", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Open.this, bollywood.class);
                startActivity(intent);
            }
        });

    }

}