package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class zumba extends AppCompatActivity {
    Button begin4, inter4, adv4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zumba);

        begin4=(Button) findViewById(R.id.begin4);
        inter4=(Button) findViewById(R.id.inter4);
        adv4=(Button) findViewById(R.id.adv4);

        begin4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(zumba.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(zumba.this, zumbabegin.class);
                startActivity(intent);
            }
        });

        inter4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(zumba.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(zumba.this, zumbainter.class);
                startActivity(intent);
            }
        });

        adv4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(zumba.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(zumba.this, zumbaadv.class);
                startActivity(intent);
            }
        });
    }
}