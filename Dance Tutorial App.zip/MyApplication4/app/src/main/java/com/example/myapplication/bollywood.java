package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class bollywood extends AppCompatActivity {
    Button begin2, inter2, adv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bollywood);
        begin2=(Button) findViewById(R.id.begin2);
        inter2=(Button) findViewById(R.id.inter2);
        adv2=(Button) findViewById(R.id.adv2);

        begin2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(bollywood.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(bollywood.this, bollybegin.class);
                startActivity(intent);
            }
        });

        inter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(bollywood.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(bollywood.this, bollyinter.class);
                startActivity(intent);
            }
        });

        adv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(bollywood.this, "Welcome", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(bollywood.this, bollyadv.class);
                startActivity(intent);
            }
        });
    }
}